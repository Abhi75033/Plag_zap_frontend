const API_URL = 'http://localhost:5001/api';

// DOM Elements
const loginView = document.getElementById('loginView');
const mainView = document.getElementById('mainView');
const loginForm = document.getElementById('loginForm');
const loginError = document.getElementById('loginError');
const logoutBtn = document.getElementById('logoutBtn');
const analyzeBtn = document.getElementById('analyzePageBtn');
const loadingState = document.getElementById('loadingState');
const resultView = document.getElementById('resultView');

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
    const token = await getToken();
    if (token) {
        showMainView(token);
    } else {
        showLoginView();
    }
});

// Login Handler
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
        const res = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await res.json();

        if (res.ok) {
            await setToken(data.token);
            showMainView(data.token);
        } else {
            showError(data.error || 'Login failed');
        }
    } catch (err) {
        showError('Could not connect to server');
    }
});

// Logout
logoutBtn.addEventListener('click', async () => {
    await chrome.storage.local.remove(['authToken']);
    showLoginView();
});

// Analyze Page
analyzeBtn.addEventListener('click', async () => {
    const token = await getToken();
    if (!token) return showLoginView();

    setLoading(true);

    try {
        // Get active tab
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

        // Execute script to get text
        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: () => {
                return document.body.innerText;
                // Or window.getSelection().toString() || document.body.innerText;
            }
        });

        const text = results[0]?.result;

        if (!text || text.length < 50) {
            throw new Error('Not enough text found on this page.');
        }

        // Send to API
        const res = await fetch(`${API_URL}/plagiarism/check`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ text })
        });

        const data = await res.json();

        if (res.ok) {
            showResults(data);
        } else {
            alert(data.error || 'Analysis failed');
        }

    } catch (err) {
        alert(err.message || 'Failed to analyze page');
    } finally {
        setLoading(false);
    }
});


// Helpers
async function getToken() {
    const data = await chrome.storage.local.get('authToken');
    return data.authToken;
}

async function setToken(token) {
    await chrome.storage.local.set({ authToken: token });
}

function showLoginView() {
    loginView.classList.remove('hidden');
    mainView.classList.add('hidden');
    logoutBtn.classList.add('hidden');
}

async function showMainView(token) {
    loginView.classList.add('hidden');
    mainView.classList.remove('hidden');
    logoutBtn.classList.remove('hidden');

    // Fetch user usage logic could go here
    document.getElementById('usageCount').innerText = 'Ready';
}

function showError(msg) {
    loginError.innerText = msg;
    loginError.classList.remove('hidden');
}

function setLoading(isLoading) {
    if (isLoading) {
        analyzeBtn.classList.add('hidden');
        loadingState.classList.remove('hidden');
        resultView.classList.add('hidden');
    } else {
        analyzeBtn.classList.remove('hidden');
        loadingState.classList.add('hidden');
    }
}

function showResults(data) {
    resultView.classList.remove('hidden');
    analyzeBtn.classList.add('hidden'); // Hide analyze button to keep focus on results

    // Scores
    const aiScore = data.aiScore || 0;
    const plagScore = 100 - (data.overallScore || 100); // Assuming overallScore is uniqueness based on previous code... 
    // Wait, in controller: overallScore = average similarity. So high similarity = high plagiarism.
    // So overallScore IS plagiarism score.

    document.getElementById('aiScore').innerText = `${aiScore}%`;
    document.getElementById('aiScore').style.color = aiScore > 50 ? '#ef4444' : '#10b981';

    document.getElementById('plagScore').innerText = `${data.overallScore}%`;
    document.getElementById('plagScore').style.color = data.overallScore > 20 ? '#ef4444' : '#10b981';

    document.getElementById('resLanguage').innerText = data.language || 'Unknown';

    document.getElementById('viewReportLink').href = `http://localhost:5173/analyzer?id=${data.id}`;
}
